function new_game(){
}

function make_move(){
}
